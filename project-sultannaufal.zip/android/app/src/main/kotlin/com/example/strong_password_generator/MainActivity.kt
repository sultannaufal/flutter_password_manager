package com.sultannaufal.password_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
